# 记忆碎片｜Memento

年份：2000。本页提供主创研究入口与知识关系，用来形成当前问题的新判断。

## 来源中的已读范围

- [S04 · BAFTA A Life in Pictures: Christopher Nolan，2017-12-01 访谈逐字稿](https://www.bafta.org/media-centre/press-releases/a-life-in-pictures-christopher-nolan/)：读取 Memento 主观信息限制、Dunkirk 悬念清晰性，以及声音/配乐融合段落；未复刻访谈全文。
- [S24 · Film Threat：Christopher Nolan 直接访谈 Part 2](https://filmthreat.com/uncategorized/part-2-nolan-christopher-with-interview-exclusive-an/)：正文：Following排练与低成本流程，Memento以倒序限制观众知识；网站探索与线性电影的区别。
- [S40 · Filmmaker / Chuck Stephens：与 Christopher / Jonathan Nolan 谈 Memento](https://filmmakermagazine.com/archives/issues/winter2001/features/past_imperfect.php)：正文：黑色电影的再判断、人物心理决定观众视点与结构；原创迁移与导演说法分开。

## 关联的电影判断

- K01 观众知道什么与时间顺序：先判断要让观众缺少哪项信息，再选择顺时、延迟或重排。 重排可能增加悬念，也增加理解负担。
- K10 音乐和剪辑的共同发展：为音乐安排一项当前叙事任务，并比较持续、变化或暂时撤掉的效果。 循环上升、低频和大音量各有用途，不能自动代替具体情感。
- K16 预算、协作与观看验证：优先取得承担关键叙事责任的素材，再决定范围与资源。 历史大制作费用不直接作为本项目报价，必要取舍由当前条件核定。

根据本轮人物、表达目标和条件选择相关概念。原片事实核对原文，新的拍法由当前场次推敲；不必找到相同问题。

## 可选原创练习与研究缺口

较早的十项原创迁移保存在[练习档案](../examples-archive/F02-memento.md)，只有需要比较设计时读取，不能归为该片实际拍法或当前使用者事实。
尚未完成合法完整片源的逐镜标注。精确焦距、灯位、场次参数需要制作证据；缺少同题例子不妨碍原创创作讨论。
